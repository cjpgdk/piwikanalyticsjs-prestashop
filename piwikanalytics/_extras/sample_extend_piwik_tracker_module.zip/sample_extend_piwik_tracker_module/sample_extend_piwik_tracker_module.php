<?php

class sample_extend_piwik_tracker_module extends Module {

    public function __construct($name = null, $context = null) {

        /* this module is only use full if piwikanalytics module is installed   */
        $this->dependencies[] = "piwikanalytics";

        $this->name = 'sample_extend_piwik_tracker_module';
        $this->tab = 'analytics_stats';
        $this->version = '1.0';
        $this->author = 'Christian M. Jensen';
        $this->displayName = 'Piwik Analytics Extened Tracking (SAMPLE)';
        $this->ps_versions_compliancy = array('min' => '1.6.0.0', 'max' => '1.6.999.999');
        parent::__construct($name, $context);
        $this->author_uri = 'http://cmjscripter.net';
        $this->url = 'http://cmjnisse.github.io/piwikanalyticsjs-prestashop/';
    }

    /* piwikTrackerStart */

    public function hookpiwikTrackerStart($param) {
        if (isset($param['piwikanalytics'])) {
            //* new isset (parsed by ref test)
            $param['piwikanalytics']->trackerStarted = "Yup!";
        }
        return "/* this need to be valid javascript*/" . PHP_EOL
                . "console.log('hookpiwikTrackerStart');" . PHP_EOL
                . "window.piwikTracker.etDownloadClasses(['myOtherDownloads','myImageDownload','myBinaryDownload'])";
    }

    /* piwikTrackerEnd */

    public function hookpiwikTrackerEnd($param) {
        $out = "";
        if (isset($param['piwikanalytics'])) {
            $out .= "alert('Works by ref ?? " . $param['piwikanalytics']->trackerStarted . "');";
        }
        return /*$out . */ "/* this need to be valid javascript*/" . PHP_EOL
                . " console.log('hookpiwikTrackerEnd');" . PHP_EOL
                . "window.piwikTracker.setDocumentTitle( ' My super Page title ' ) ";
    }

    /* piwikTrackerSiteSearch */

    public function hookpiwikTrackerSiteSearch($param) {
        /* called from hookactionSearch */
        // $param['piwikanalytics']
        return "/* this need to be valid javascript or an empty string */";
    }

    /* piwikTrackerPageView */

    public function hookpiwikTrackerPageView($param) {
        // $param['piwikanalytics']
        return "/* this need to be valid javascript or an empty string */";
    }

    public function install() {
        if ((!parent::install() || !$this->registerHook('piwikTrackerPageView') ||
                !$this->registerHook('piwikTrackerSiteSearch') ||
                !$this->registerHook('piwikTrackerEnd') ||
                !$this->registerHook('piwikTrackerStart'))) {
            return false;
        }
        return true;
    }

}
